import requests
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render, redirect


# Create your views here.
def get_full_name(request, user_id_session_key):
    global full_name
    try:
        response = requests.get('http://rt.dczambia.com/api/users/' + str(user_id_session_key))
        response_data = response.json()
        print('RESPONSE DATA: ', response_data)
        full_name = response_data["first_name"] + ' ' + response_data["last_name"]

        return full_name

    except requests.exceptions.Timeout:
        # Maybe set up for a retry, or continue in a retry loop
        return render(request, 'dashboard.html', {'error': 'Request Timeout!'})
    except requests.exceptions.ConnectionError:
        # Maybe set up for a retry, or continue in a retry loop
        return render(request, 'dashboard.html', {'error': 'Check internet Connection!'})
    except requests.exceptions.TooManyRedirects:
        # Tell the user their URL was bad and try a different one
        return render(request, 'dashboard.html', {'error': 'Bad URL, try a different one!'})
    except requests.exceptions.RequestException as e:
        # catastrophic error. bail.
        return render(request, 'dashboard.html', {'error': 'General error, contact support!'})


#
def get_user_role(request, user_id_session_key):
    global user_role
    try:
        response = requests.get('http://rt.dczambia.com/api/users/' + str(user_id_session_key))
        response_data = response.json()
        print('RESPONSE DATA: ', response_data)
        user_role = response_data["user_role"]

        return user_role

    except requests.exceptions.Timeout:
        # Maybe set up for a retry, or continue in a retry loop
        return render(request, 'dashboard.html', {'error': 'Request Timeout!'})
    except requests.exceptions.ConnectionError:
        # Maybe set up for a retry, or continue in a retry loop
        return render(request, 'dashboard.html', {'error': 'Check internet Connection!'})
    except requests.exceptions.TooManyRedirects:
        # Tell the user their URL was bad and try a different one
        return render(request, 'dashboard.html', {'error': 'Bad URL, try a different one!'})
    except requests.exceptions.RequestException as e:
        # catastrophic error. bail.
        return render(request, 'dashboard.html', {'error': 'General error, contact support!'})


# login user
def login_user(request):
    if request.session.has_key('checklistsessionusername'):
        user_name_session_key = request.session['checklistsessionusername']
        if user_name_session_key:
            return redirect('dashboard')
    else:
        if request.POST:
            print('USERNAME: ', request.POST.get('username'))
            print('PASSWORD: ', request.POST.get('password'))
            url = 'http://rt.dczambia.com/api/user-login/'
            post_data = {
                "username": request.POST.get('username'),
                "password": request.POST.get('password')
            }
            try:
                response = requests.post(url, json=post_data)
                print('JSON RESPONSE: ', response.json())
                response_data = response.json()

                if response_data["message"] == "user logged in":
                    print('THE MESSAGE: ', response_data["message"])
                    request.session['checklistsessionusername'] = response_data["username"]
                    request.session['checklistsessionuserid'] = response_data["id"]
                    # if request.session.has_key('checklistsessionusername'):
                    #     user_name_session_key = request.session['checklistsessionusername']

                    return redirect('dashboard')
                else:
                    # print(response_data["responseDesc"])
                    return render(request, 'user_login.html',
                                  {
                                      'response_message': response_data["message"],
                                  })
            except requests.exceptions.Timeout:
                # Maybe set up for a retry, or continue in a retry loop
                return render(request, 'user_login.html', {'error': 'Request Timeout!'})
            except requests.exceptions.ConnectionError:
                # Maybe set up for a retry, or continue in a retry loop
                return render(request, 'user_login.html', {'error': 'Check internet Connection!'})
            except requests.exceptions.TooManyRedirects:
                # Tell the user their URL was bad and try a different one
                return render(request, 'user_login.html', {'error': 'Bad URL, try a different one!'})
            except requests.exceptions.RequestException as e:
                # catastrophic error. bail.
                return render(request, 'user_login.html', {'error': 'General error, contact support!'})

        return render(request, 'user_login.html', {})


# update user password
def update_user_password(request):
    global user_name_session_key
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            if request.POST:
                #print('USERNAME: ', request.POST.get('username'))
                print('OLD PASSWORD: ', request.POST.get('old_password'))
                print('NEW PASSWORD: ', request.POST.get('new_password'))
                url = 'http://rt.dczambia.com0/api/user/update-password/'
                post_data = {
                    "username": user_name_session_key,
                    "old_password": request.POST.get('old_password'),
                    "new_password": request.POST.get('new_password')
                }
                try:
                    response = requests.post(url, json=post_data)
                    print('JSON RESPONSE: ', response.json())
                    response_data = response.json()

                    if response_data["message"] == "Password updated successfully":
                        print('THE MESSAGE: ', response_data["message"])

                        return redirect('logout_user')
                    else:
                        # print(response_data["responseDesc"])
                        return render(request, 'user_update_password_form.html',
                                      {
                                          'response_message': response_data["message"],
                                          'users_role': get_user_role(request, user_id_session_key),
                                          'username': get_full_name(request, user_id_session_key),
                                      })
                except requests.exceptions.Timeout:
                    # Maybe set up for a retry, or continue in a retry loop
                    return render(request, 'user_update_password_form.html', {'error': 'Request Timeout!'})
                except requests.exceptions.ConnectionError:
                    # Maybe set up for a retry, or continue in a retry loop
                    return render(request, 'user_update_password_form.html', {'error': 'Check internet Connection!'})
                except requests.exceptions.TooManyRedirects:
                    # Tell the user their URL was bad and try a different one
                    return render(request, 'user_update_password_form.html', {'error': 'Bad URL, try a different one!'})
                except requests.exceptions.RequestException as e:
                    # catastrophic error. bail.
                    return render(request, 'user_update_password_form.html', {'error': 'General error, contact support!'})
            else:
                return render(request, 'user_update_password_form.html',
                              {
                                  'users_role': get_user_role(request, user_id_session_key),
                                  'username': get_full_name(request, user_id_session_key),
                              })

    return redirect('login_user')



# logouts a user
def logout_user(request):
    request.session.pop("checklistsessionusername", None)
    request.session.pop("checklistsessionuserid", None)
    return redirect('login_user')


# loads dashboard
def Dashboard(request):
    global user_name_session_key
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']

        # get all vehicles
        response = requests.get('http://rt.dczambia.com/api/vehicle-driver-count/')
        valid_road_tax_response = requests.get('http://rt.dczambia.com/api/vehicle-valid-road-tax-count/')
        vehicles_and_drivers = response.json()
        valid_road_tax_count = response.json()

        return render(request, 'dashboard.html',
                      {
                          'username': get_full_name(request, user_id_session_key),
                          'users_role': get_user_role(request, user_id_session_key),
                          'vehicles_and_drivers': vehicles_and_drivers,
                          'valid_road_tax_count': valid_road_tax_count,
                      })
    else:
        return redirect('login_user')


# registers a user
def RegisterUser(request):
    global user_name_session_key
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            if request.method == 'POST':
                payload = {
                    "username": request.POST.get('username'),
                    "first_name": request.POST.get('first_name'),
                    "last_name": request.POST.get('last_name'),
                    "email": request.POST.get('email'),
                    "user_role": request.POST.get('user_role'),
                    # "is_road_agent": request.POST.get('is_road_agent'),
                    # "is_superuser": request.POST.get('is_superuser'),
                    "phone_number": request.POST.get('phone_number'),
                    "password": request.POST.get('username'),
                    "password2": request.POST.get('username'),
                    "gender": request.POST.get('gender')
                }
                response = requests.post('http://rt.dczambia.com/api/user-register/', json=payload)
                reg_data = response.json()
                print('RETURNED DATA: ', reg_data)

                if response.status_code == 201:
                    # print('RETURNED DATA: ', reg_data["response_code"])
                    return redirect('user_added_successfully')

                else:
                    return render(request, 'user_registration_form.html',
                                  {
                                      # 'response_code': reg_data['response_code'],
                                      'response_message': response.status_code,
                                      'username': get_full_name(request, user_id_session_key),
                                      'users_role': get_user_role(request, user_id_session_key)
                                  })
            return render(request, 'user_registration_form.html',
                          {
                              'username': get_full_name(request, user_id_session_key),
                              'users_role': get_user_role(request, user_id_session_key)
                          })
    else:
        return redirect('login_user')


# lists all users
def GetAllUsers(request):
    global user_name_session_key
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            response = requests.get('http://rt.dczambia.com/api/users/')
            user_details = response.json()

            page = request.GET.get('page', 1)
            paginator = Paginator(user_details, 8)
            try:
                users_D = paginator.page(page)
            except PageNotAnInteger:
                users_D = paginator.page(1)
            except EmptyPage:
                users_D = paginator.page(paginator.num_pages)
            return render(request, 'users.html',
                          {
                              'userdetails': users_D,
                              'username': get_full_name(request, user_id_session_key),
                              'users_role': get_user_role(request, user_id_session_key)
                          })
    else:
        return redirect('login_user')


# def user_details(request, user_name):
#     if request.session.has_key('helpdesksessionuserid'):
#         username = request.session['helpdesksessionuserid']
#         if username:
#             try:
#                 url = 'http://172.16.157.130:8080/api/user-details'
#                 post_data = {
#                     "api_key": "123456789",
#                     "user_name": user_name
#                 }
#                 response = requests.post(url, json=post_data)
#                 user_details = response.json()
#
#             except requests.exceptions.Timeout:
#                 # Maybe set up for a retry, or continue in a retry loop
#                 return render(request, 'clientapp/list_users.html',
#                               {'user_role': get_user_role(request, username), 'error': 'Request Timeout!'})
#             except requests.exceptions.ConnectionError:
#                 # Maybe set up for a retry, or continue in a retry loop
#                 return render(request, 'clientapp/list_users.html',
#                               {'user_role': get_user_role(request, username), 'error': 'Check internet Connection!'})
#             except requests.exceptions.TooManyRedirects:
#                 # Tell the user their URL was bad and try a different one
#                 return render(request, 'clientapp/list_users.html',
#                               {'user_role': get_user_role(request, username), 'error': 'Bad URL, try a different one!'})
#             except requests.exceptions.RequestException as e:
#                 # catastrophic error. bail.
#                 return render(request, 'clientapp/list_users.html', {'user_role': get_user_role(request, username),
#                                                                      'error': 'General error, contact support!'})
#             return render(request, 'clientapp/user_details.html',
#                           {
#                               'user_details': user_details,
#                               'username': get_full_name(request, username),
#                               'user_role': get_user_role(request, username)
#                           })
#     else:
#         return render(request, 'clientapp/login_form.html', {})


# search for user
def SearchUser(request):
    global user_details
    global user_name_session_key
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            keywords = request.GET.get('searchuser')
            if keywords:
                response = requests.get('http://rt.dczambia.com/api/users/?search=' + keywords)
                user_details = response.json()

                page = request.GET.get('page', 1)
                paginator = Paginator(user_details, 8)
                try:
                    users_D = paginator.page(page)
                except PageNotAnInteger:
                    users_D = paginator.page(1)
                except EmptyPage:
                    users_D = paginator.page(paginator.num_pages)
                return render(request, 'users.html',
                              {
                                  'userdetails': users_D,
                                  'keywords': keywords,
                                  'username': get_full_name(request, user_id_session_key),
                                  'users_role': get_user_role(request, user_id_session_key)
                              })
            else:
                response = requests.get('http://rt.dczambia.com/api/users/')
                user_details = response.json()
                return render(request, 'users.html',
                              {
                                  'userdetails': user_details,
                                  'username': get_full_name(request, user_id_session_key),
                                  'users_role': get_user_role(request, user_id_session_key)
                              })
    else:
        return redirect('login_user')


# Get Vehicle and drivers list
def GetAllVehiclesAndDrivers(request):
    global user_name_session_key
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            response = requests.get('http://rt.dczambia.com/api/vehicle-driver-details/')
            vehicles_and_drivers = response.json()

            page = request.GET.get('page', 1)
            paginator = Paginator(vehicles_and_drivers, 8)
            try:
                V_D = paginator.page(page)
            except PageNotAnInteger:
                V_D = paginator.page(1)
            except EmptyPage:
                V_D = paginator.page(paginator.num_pages)
            return render(request, 'vehicles_and_drivers_list.html',
                          {
                              'vehicles_and_drivers': V_D,
                              'username': get_full_name(request, user_id_session_key),
                              'users_role': get_user_role(request, user_id_session_key)
                          })
    else:
        return redirect('login_user')


# search vehicle
def SearchVehicleOrDriver(request):
    global user_details
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            keywords = request.GET.get('searchvehicledriver')
            if keywords:
                response = requests.get('http://rt.dczambia.com/api/vehicle-driver-details/?search=' + keywords)
                vehicles_and_drivers = response.json()
                return render(request, 'vehicles_and_drivers_list.html',
                              {
                                  'vehicles_and_drivers': vehicles_and_drivers,
                                  'keywords': keywords,
                                  'username': get_full_name(request, user_id_session_key),
                              })
            else:
                response = requests.get('http://rt.dczambia.com/api/vehicle-driver-details/')
                vehicles_and_drivers = response.json()
                return render(request, 'vehicles_and_drivers_list.html',
                              {
                                  'vehicles_and_drivers': vehicles_and_drivers,
                                  'username': get_full_name(request, user_id_session_key),
                                  'users_role': get_user_role(request, user_id_session_key)
                              })

    else:
        return redirect('login_user')


def AddVehicleAndDriver(request):
    global user_name_session_key
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            if request.method == 'POST':
                payload = {
                    "vehicleOperatorName": request.POST.get('operatorname'),
                    "vehicleRegistrationNumber": request.POST.get('registrationnumber'),
                    "vehicleMake": request.POST.get('vehiclemake'),
                    "vehicleSittingCapacity": request.POST.get('sittingcapacity'),
                    "vehicleSeatBelts": request.POST.get('seatbelts'),
                    "roadTax": request.POST.get('roadtax'),
                    "insurance": request.POST.get('insurance'),
                    "roadServiceLicense": request.POST.get('roadservicelicense'),
                    "roadWorthiness": request.POST.get('roadworthiness'),
                    "tyres": request.POST.get('tyres'),
                    "fireExtinguisher": request.POST.get('fireextinguisher'),
                    "firstAidBox": request.POST.get('firstaidbox'),
                    "triangles": request.POST.get('triangles'),
                    "lights": request.POST.get('lights'),
                    "hooter": request.POST.get('hooter'),
                    "wipers": request.POST.get('wipers'),
                    "transmission": request.POST.get('transmission'),
                    "firstName": request.POST.get('firstname'),
                    "lastName": request.POST.get('lastname'),
                    "nrcNumber": request.POST.get('nrc'),
                    "age": request.POST.get('age'),
                    "psvCategory": request.POST.get('psvcategory'),
                    "validity": request.POST.get('validity'),
                    "signature": request.POST.get('output'),
                    "startPoint": request.POST.get('startpoint'),
                    "destination": request.POST.get('destination'),
                    "checkedBy": user_name_session_key
                }
                response = requests.post('http://rt.dczambia.com/api/vehicle-driver-details/', json=payload)
                reg_data = response.json()
                print('START POINT DATA: ', request.POST.get('startpoint'))
                print('SIGNATURE DATA: ', request.POST.get('output'))

                if response.status_code == 201:
                    # print('RETURNED DATA: ', reg_data["response_code"])
                    return redirect('vehicles_drivers')

                else:
                    return render(request, 'add_vehicle_and_driver.html',
                                  {
                                      'response_data': reg_data,
                                      'response_message': response.status_code,
                                      'username': get_full_name(request, user_id_session_key),
                                      'users_role': get_user_role(request, user_id_session_key)
                                  })
            return render(request, 'add_vehicle_and_driver.html',
                          {
                              'username': get_full_name(request, user_id_session_key),
                              'users_role': get_user_role(request, user_id_session_key)
                          })
    else:
        return redirect('login_user')


def VehicleAndDriverDetail(request, id):
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            try:
                response = requests.get('http://rt.dczambia.com/api/vehicle-driver-details/' + str(id))
                vehicle_driver_details = response.json()

            except requests.exceptions.Timeout:
                # Maybe set up for a retry, or continue in a retry loop
                return render(request, 'vehicle_details.html',
                              {'error': 'Request Timeout!'})
            except requests.exceptions.ConnectionError:
                # Maybe set up for a retry, or continue in a retry loop
                return render(request, 'vehicle_details.html',
                              {'error': 'Check internet Connection!'})
            except requests.exceptions.TooManyRedirects:
                # Tell the user their URL was bad and try a different one
                return render(request, 'vehicle_details.html',
                              {'error': 'Bad URL, try a different one!'})
            except requests.exceptions.RequestException as e:
                # catastrophic error. bail.
                return render(request, 'vehicle_details.html', {
                    'error': 'General error, contact support!'
                })
            return render(request, 'vehicle_details.html',
                          {
                              'vehicle_driver_details': vehicle_driver_details,
                              'username': get_full_name(request, user_id_session_key),
                              'users_role': get_user_role(request, user_id_session_key)
                          })
    else:
        return render(request, 'user_login.html', {})


def UserAddedSuccessPage(request):
    global user_name_session_key
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']

        return render(request, 'user_created_successfully.html',
                      {
                          'username': get_full_name(request, user_id_session_key),
                          'users_role': get_user_role(request, user_id_session_key)
                      })
    else:
        return redirect('login_user')


def AdminEditUserDetails(request, id):
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            user_response = requests.get('http://rt.dczambia.com/api/users/' + str(id))
            response_user_details = user_response.json()
            if request.method == 'POST':
                payload = {
                    "username": request.POST.get('username'),
                    "first_name": request.POST.get('first_name'),
                    "last_name": request.POST.get('last_name'),
                    "email": request.POST.get('email'),
                    "user_role": request.POST.get('user_role'),
                    "phone_number": request.POST.get('phone_number'),
                    "gender": request.POST.get('gender')
                }
                try:
                    response = requests.put('http://rt.dczambia.com/api/users/' + str(id) + '/', data=payload)
                    response_details = response.json()
                    if response.status_code == 200:
                        return redirect('user_list')

                    else:
                        return render(request, 'user_edit_form.html',
                                      {
                                          'response_user_details': response_user_details,
                                          'response_code': response.status_code,
                                          'response_message': response_details,
                                          'username': get_full_name(request, user_id_session_key),
                                          'users_role': get_user_role(request, user_id_session_key)
                                      })

                except requests.exceptions.Timeout:
                    # Maybe set up for a retry, or continue in a retry loop
                    return render(request, 'user_edit_form.html',
                                  {'error': 'Request Timeout!'})
                except requests.exceptions.ConnectionError:
                    # Maybe set up for a retry, or continue in a retry loop
                    return render(request, 'user_edit_form.html',
                                  {'error': 'Check internet Connection!'})
                except requests.exceptions.TooManyRedirects:
                    # Tell the user their URL was bad and try a different one
                    return render(request, 'user_edit_form.html',
                                  {'error': 'Bad URL, try a different one!'})
                except requests.exceptions.RequestException as e:
                    # catastrophic error. bail.
                    return render(request, 'user_edit_form.html', {
                        'error': 'General error, contact support!'
                    })
            return render(request, 'user_edit_form.html',
                          {
                              'response_user_details': response_user_details,
                              'username': get_full_name(request, user_id_session_key),
                              'users_role': get_user_role(request, user_id_session_key)
                          })
    else:
        return render(request, 'user_login.html', {})


# delete user
def AdminDeleteUser(request, id):
    if request.session.has_key('checklistsessionusername') and request.session.has_key('checklistsessionuserid'):
        user_name_session_key = request.session['checklistsessionusername']
        user_id_session_key = request.session['checklistsessionuserid']
        if user_name_session_key:
            try:
                response = requests.delete('http://127.0.0.1:8000/api/users/' + str(id))
                response_details = response.raw
                print('RESPONSE: ', response_details)
                if response.status_code == 204:
                    return redirect('user_list')
                    # return render(request, 'users.html',
                    #               {
                    #                   'response_code': response.status_code,
                    #                   'response_message_del': 'User Deleted Successfully!',
                    #                   'username': get_full_name(request, user_id_session_key),
                    #                   'users_role': get_user_role(request, user_id_session_key)
                    #               })

                else:
                    return render(request, 'users.html',
                                  {
                                      'response_code': response.status_code,
                                      'response_message': response_details,
                                      'username': get_full_name(request, user_id_session_key),
                                      'users_role': get_user_role(request, user_id_session_key)
                                  })

            except requests.exceptions.Timeout:
                # Maybe set up for a retry, or continue in a retry loop
                return render(request, 'users.html',
                              {'error': 'Request Timeout!'})
            except requests.exceptions.ConnectionError:
                # Maybe set up for a retry, or continue in a retry loop
                return render(request, 'users.html',
                              {'error': 'Check internet Connection!'})
            except requests.exceptions.TooManyRedirects:
                # Tell the user their URL was bad and try a different one
                return render(request, 'users.html',
                              {'error': 'Bad URL, try a different one!'})
            except requests.exceptions.RequestException as e:
                # catastrophic error. bail.
                return render(request, 'users.html', {
                    'error': 'General error, contact support!'
                })
        return render(request, 'users.html',
                      {
                          'username': get_full_name(request, user_id_session_key),
                          'users_role': get_user_role(request, user_id_session_key)
                      })
    else:
        return render(request, 'user_login.html', {})
