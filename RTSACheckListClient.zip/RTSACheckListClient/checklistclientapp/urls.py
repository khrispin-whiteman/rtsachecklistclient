from django.urls import path
from django.views.decorators.csrf import csrf_exempt

from checklistclientapp import views

urlpatterns = [
    path('dashboard/', views.Dashboard, name='dashboard'),
    path('users-list/', views.GetAllUsers, name='user_list'),
    path('users-list/update/<int:id>/', views.AdminEditUserDetails, name='update_user_admin'),
    path('users-list/delete/<int:id>/', views.AdminDeleteUser, name='delete_user_admin'),
    path('search-user/', views.SearchUser, name='search_user'),
    path('vehicles-drivers-list/', csrf_exempt(views.GetAllVehiclesAndDrivers), name='vehicles_drivers'),
    path('vehicles-drivers-list/<int:id>', views.VehicleAndDriverDetail, name='vehicle_and_driver_details'),
    path('search-vd/', views.SearchVehicleOrDriver, name='search_vehicles_drivers'),
    path('add-vehicle-driver/', views.AddVehicleAndDriver, name='add_vehicle_driver'),
    path('add-user/', views.RegisterUser, name='register_user'),
    path('accounts/login/', views.login_user, name='login_user'),
    path('logout-user/', views.logout_user, name='logout_user'),
    path('add-user/successfully-added/', views.UserAddedSuccessPage, name='user_added_successfully'),
    path('user/update-password/', views.update_user_password, name='update_user_password'),
]
